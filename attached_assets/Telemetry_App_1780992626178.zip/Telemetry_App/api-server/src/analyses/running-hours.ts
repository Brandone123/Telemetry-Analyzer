import ExcelJS from "exceljs";
import { parseAllSheets, parseSheet, isSlaProject, type Row } from "../lib/excel-utils";

export interface RHOptions {
  periodDays: number; // typically 4
  lowThresholdHours: number; // sites with total RH below → investigate (default 80 for 4 days)
  highThresholdHours: number; // sites above → investigate too high (default 24*periodDays * 0.95 for example)
  batteryAbnormalThreshold: number; // sites at site-down with battery > this → abnormal alarm (default 47.5)
}

export interface RHResult {
  buffer: Buffer;
  filename: string;
  summary: {
    totalRows: number;
    slaSites: number;
    excludedNoComm: number;
    excludedOpenPower: number;
    excludedOpenGen: number;
    candidates: number;
    lowRH: number;
    highRH: number;
    abnormalSiteDown: number;
  };
}

function pickField(row: Row, candidates: string[]): string {
  for (const c of candidates) {
    for (const k of Object.keys(row)) {
      if (k.toLowerCase().trim() === c.toLowerCase().trim()) {
        const v = row[k];
        if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
      }
    }
  }
  return "";
}

function num(v: string): number {
  if (!v) return 0;
  const n = parseFloat(String(v).replace(/,/g, ""));
  return Number.isNaN(n) ? 0 : n;
}

interface ERSAggregate {
  site: string;
  region: string;
  projectStatus: string;
  powerTopology: string;
  days: Set<string>;
  totalRH: number;
  totalDownH: number;
  totalNoCommH: number;
  maxBatteryV: number; // not in dataset typically, leave 0
  rhPerDay: Map<string, number>;
  abnormalDays: number;
}

export async function analyzeRunningHours(
  ersBuffer: Buffer,
  commBuffer: Buffer | null,
  powerTicketsBuffer: Buffer | null,
  genTicketsBuffer: Buffer | null,
  options: RHOptions,
): Promise<RHResult> {
  // ERS Big Data — find sheet that has Day + Gen RH columns
  const allSheets = parseAllSheets(ersBuffer);
  let ersRows: Row[] = [];
  for (const [name, rows] of Object.entries(allSheets)) {
    if (rows.length === 0) continue;
    const first = rows[0]!;
    const keys = Object.keys(first).map((k) => k.toLowerCase());
    if (keys.some((k) => k.includes("totalpower")) || keys.some((k) => k.includes("gen rh") || k.includes("genrh"))) {
      ersRows = rows;
      break;
    }
    if (name.toLowerCase().includes("ers big data")) {
      ersRows = rows;
      break;
    }
  }
  if (ersRows.length === 0) {
    // fallback to last sheet
    const names = Object.keys(allSheets);
    if (names.length > 0) ersRows = allSheets[names[names.length - 1]!]!;
  }

  // Aggregate per site
  const agg = new Map<string, ERSAggregate>();
  for (const r of ersRows) {
    const site = pickField(r, ["SiteName", "Site", "Site Name"]);
    if (!site) continue;
    const projectStatus = pickField(r, ["ProjectStatus", "Project Status", "projectStatus"]);
    if (!isSlaProject(projectStatus)) continue;
    const day = pickField(r, ["Day", "Date"]);
    let a = agg.get(site);
    if (!a) {
      a = {
        site,
        region: pickField(r, ["RegionName", "Region"]),
        projectStatus,
        powerTopology: pickField(r, ["PowerTopology", "Power Topology"]),
        days: new Set(),
        totalRH: 0,
        totalDownH: 0,
        totalNoCommH: 0,
        maxBatteryV: 0,
        rhPerDay: new Map(),
        abnormalDays: 0,
      };
      agg.set(site, a);
    }
    if (day) a.days.add(day);
    const genRH = num(pickField(r, ["Gen RH", "GenRH", "Generator Working H"]));
    const totalRH = num(pickField(r, ["TotalPower RH", "TotalPower RH", "Total RH"]));
    const downH = num(pickField(r, ["SiteDown H", "SiteDown", "SiteDownH"]));
    const noComm = num(pickField(r, ["No Comm. H", "No Comm H", "NoComm H"]));
    a.totalRH += totalRH || genRH;
    a.totalDownH += downH;
    a.totalNoCommH += noComm;
    a.rhPerDay.set(day, (a.rhPerDay.get(day) ?? 0) + (totalRH || genRH));
    const abnormal = pickField(r, ["LoadProfile", "Load Profile"]);
    if (abnormal && abnormal.toLowerCase().includes("abnormal")) a.abnormalDays += 1;
  }

  // Communication report — sites NOT communicating
  const notCommSet = new Set<string>();
  if (commBuffer) {
    const commRows = parseSheet(commBuffer);
    for (const r of commRows) {
      const site = pickField(r, ["Site", "SiteName"]);
      if (!site) continue;
      const projectStatus = pickField(r, ["projectStatus", "Project Status"]);
      if (!isSlaProject(projectStatus)) continue;
      const status = pickField(r, ["Status"]);
      if (status.toUpperCase() !== "OK") notCommSet.add(site);
    }
  }

  // Open power tickets
  const openPowerSet = new Set<string>();
  if (powerTicketsBuffer) {
    const tRows = parseSheet(powerTicketsBuffer);
    for (const r of tRows) {
      const site = pickField(r, ["Site"]);
      const status = pickField(r, ["Status"]);
      const cat = pickField(r, ["Category", "Type"]);
      if (!site) continue;
      if (status.toLowerCase() === "open" && /power|running hours/i.test(cat + " " + pickField(r, ["Type", "Item"]))) {
        openPowerSet.add(site);
      } else if (status.toLowerCase() === "open") {
        openPowerSet.add(site); // assume file is power tickets only
      }
    }
  }

  // Open generator tickets
  const openGenSet = new Set<string>();
  if (genTicketsBuffer) {
    const tRows = parseSheet(genTicketsBuffer);
    for (const r of tRows) {
      const site = pickField(r, ["Site"]);
      const status = pickField(r, ["Status"]);
      if (!site) continue;
      if (status.toLowerCase() === "open") openGenSet.add(site);
    }
  }

  // Build classified list
  type Classified = {
    site: string;
    region: string;
    projectStatus: string;
    powerTopology: string;
    daysCount: number;
    totalRH: number;
    avgRH: number;
    siteDownH: number;
    noCommH: number;
    abnormalDays: number;
    excludedReason: string;
    flag: string; // LOW | HIGH | OK | ABNORMAL_DOWN
  };
  const list: Classified[] = [];
  let excludedNoComm = 0, excludedOpenPower = 0, excludedOpenGen = 0;

  const high = options.highThresholdHours;
  const low = options.lowThresholdHours;

  for (const a of agg.values()) {
    let excluded = "";
    if (notCommSet.has(a.site)) { excluded = "Not communicating"; excludedNoComm++; }
    else if (openPowerSet.has(a.site)) { excluded = "Open Power ticket"; excludedOpenPower++; }
    else if (openGenSet.has(a.site)) { excluded = "Open Generator ticket"; excludedOpenGen++; }

    const totalRH = Math.round(a.totalRH * 100) / 100;
    const daysCount = a.days.size || options.periodDays;
    const avgRH = Math.round((totalRH / Math.max(1, daysCount)) * 100) / 100;

    let flag = "OK";
    if (!excluded) {
      // Only flag LOW when the site was genuinely up (no significant downtime or no-comm
      // periods that would naturally depress the RH reading). Allow up to ~4 h/day for
      // maintenance windows; anything above that means the low RH is expected / explained.
      const maxDownAllowed = options.periodDays * 4;
      const maxNoCommAllowed = options.periodDays * 4;
      const genuineLow = totalRH < low
        && a.totalDownH < maxDownAllowed
        && a.totalNoCommH < maxNoCommAllowed;
      if (genuineLow) flag = "LOW (investigate)";
      else if (totalRH > high) flag = "HIGH (investigate)";
    }

    list.push({
      site: a.site,
      region: a.region,
      projectStatus: a.projectStatus,
      powerTopology: a.powerTopology,
      daysCount,
      totalRH,
      avgRH,
      siteDownH: Math.round(a.totalDownH * 100) / 100,
      noCommH: Math.round(a.totalNoCommH * 100) / 100,
      abnormalDays: a.abnormalDays,
      excludedReason: excluded,
      flag,
    });
  }

  // Abnormal site-down: site has SiteDown H > 0 but is communicating + load profile abnormal
  // (We can't see battery voltage in ERS standard columns, so we use abnormal load profile + sitedown > 0 as proxy)
  const abnormalDown = list.filter((c) => !c.excludedReason && c.siteDownH > 1 && c.abnormalDays > 0);

  const candidates = list.filter((c) => !c.excludedReason);
  const lowSites = candidates.filter((c) => c.flag.startsWith("LOW"));
  const highSites = candidates.filter((c) => c.flag.startsWith("HIGH"));

  // Build workbook
  const wb = new ExcelJS.Workbook();
  wb.creator = "Telemetry Analyzer";
  wb.created = new Date();

  // ---- All Sites RH ----
  const ws = wb.addWorksheet("All Sites RH");
  ws.columns = [
    { header: "Region", key: "region", width: 16 },
    { header: "Site", key: "site", width: 18 },
    { header: "Project Status", key: "projectStatus", width: 16 },
    { header: "Power Topology", key: "powerTopology", width: 28 },
    { header: "Days Counted", key: "daysCount", width: 12 },
    { header: "Total RH (h)", key: "totalRH", width: 14 },
    { header: "Avg RH/day", key: "avgRH", width: 12 },
    { header: "Site Down H", key: "siteDownH", width: 12 },
    { header: "No Comm H", key: "noCommH", width: 12 },
    { header: "Abnormal Days", key: "abnormalDays", width: 14 },
    { header: "Excluded Reason", key: "excludedReason", width: 22 },
    { header: "Flag", key: "flag", width: 18 },
  ];
  ws.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
  ws.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F4E78" } };

  // params block
  ws.getCell("N1").value = "Period Days"; ws.getCell("O1").value = options.periodDays;
  ws.getCell("N2").value = "Low Threshold (h)"; ws.getCell("O2").value = options.lowThresholdHours;
  ws.getCell("N3").value = "High Threshold (h)"; ws.getCell("O3").value = options.highThresholdHours;
  ws.getColumn(14).font = { bold: true };

  list.forEach((c, i) => {
    const r = i + 2;
    ws.addRow(c);
    // Override Avg RH with formula to make it auditable
    ws.getCell(`G${r}`).value = { formula: `IF(E${r}=0,0,F${r}/E${r})` };
    ws.getCell(`G${r}`).numFmt = "0.00";
    ws.getCell(`F${r}`).numFmt = "0.00";
    ws.getCell(`H${r}`).numFmt = "0.00";
    ws.getCell(`I${r}`).numFmt = "0.00";
    // Flag computed by formula too
    ws.getCell(`L${r}`).value = {
      formula: `IF(K${r}<>"","EXCLUDED",IF(F${r}<$O$2,"LOW (investigate)",IF(F${r}>$O$3,"HIGH (investigate)","OK")))`,
    };
  });

  ws.autoFilter = { from: "A1", to: "L1" };
  ws.views = [{ state: "frozen", ySplit: 1 }];

  // Conditional formatting on Flag
  ws.addConditionalFormatting({
    ref: `L2:L${list.length + 1}`,
    rules: [
      { type: "containsText", operator: "containsText", text: "LOW", priority: 1, style: { fill: { type: "pattern", pattern: "solid", bgColor: { argb: "FFF8CBAD" } } } },
      { type: "containsText", operator: "containsText", text: "HIGH", priority: 2, style: { fill: { type: "pattern", pattern: "solid", bgColor: { argb: "FFFFC000" } } } },
      { type: "containsText", operator: "containsText", text: "EXCLUDED", priority: 3, style: { fill: { type: "pattern", pattern: "solid", bgColor: { argb: "FFD9D9D9" } } } },
    ],
  });
  ws.addConditionalFormatting({
    ref: `F2:F${list.length + 1}`,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rules: [{ type: "dataBar", priority: 4, cfvo: [{ type: "min" }, { type: "max" }], color: { argb: "FF1F4E78" } } as any],
  });

  // ---- Sites to Investigate (LOW + HIGH) ----
  const wsInv = wb.addWorksheet("To Investigate");
  wsInv.mergeCells("A1:H1");
  wsInv.getCell("A1").value = `RH Sites to INVESTIGATE — Period ${options.periodDays} days`;
  wsInv.getCell("A1").font = { bold: true, size: 14, color: { argb: "FFFFFFFF" } };
  wsInv.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFC00000" } };
  wsInv.getCell("A1").alignment = { horizontal: "center" };
  wsInv.getRow(2).values = ["Region", "Site", "Project Status", "Power Topology", "Total RH", "Avg RH/day", "Site Down H", "Flag"];
  wsInv.getRow(2).font = { bold: true };
  wsInv.getRow(2).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFD9E1F2" } };

  const investigate = [...lowSites, ...highSites].sort((a, b) => a.totalRH - b.totalRH);
  investigate.forEach((c, i) => {
    const r = i + 3;
    wsInv.getCell(`A${r}`).value = c.region;
    wsInv.getCell(`B${r}`).value = c.site;
    wsInv.getCell(`C${r}`).value = c.projectStatus;
    wsInv.getCell(`D${r}`).value = c.powerTopology;
    wsInv.getCell(`E${r}`).value = c.totalRH;
    wsInv.getCell(`E${r}`).numFmt = "0.00";
    wsInv.getCell(`F${r}`).value = { formula: `IF(${c.daysCount}=0,0,E${r}/${c.daysCount})` };
    wsInv.getCell(`F${r}`).numFmt = "0.00";
    wsInv.getCell(`G${r}`).value = c.siteDownH;
    wsInv.getCell(`G${r}`).numFmt = "0.00";
    wsInv.getCell(`H${r}`).value = c.flag;
  });
  wsInv.columns = [
    { width: 16 }, { width: 18 }, { width: 16 }, { width: 28 }, { width: 14 }, { width: 14 }, { width: 14 }, { width: 18 },
  ];
  wsInv.autoFilter = { from: "A2", to: "H2" };
  wsInv.views = [{ state: "frozen", ySplit: 2 }];
  wsInv.addConditionalFormatting({
    ref: `H3:H${investigate.length + 2}`,
    rules: [
      { type: "containsText", operator: "containsText", text: "LOW", priority: 1, style: { fill: { type: "pattern", pattern: "solid", bgColor: { argb: "FFF8CBAD" } } } },
      { type: "containsText", operator: "containsText", text: "HIGH", priority: 2, style: { fill: { type: "pattern", pattern: "solid", bgColor: { argb: "FFFFC000" } } } },
    ],
  });

  // ---- Abnormal Site Down ----
  const wsAbn = wb.addWorksheet("Abnormal Site Down");
  wsAbn.mergeCells("A1:F1");
  wsAbn.getCell("A1").value = "Sites in Site-Down with Abnormal Load Profile (likely false alarms — close)";
  wsAbn.getCell("A1").font = { bold: true, size: 13, color: { argb: "FFFFFFFF" } };
  wsAbn.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFED7D31" } };
  wsAbn.getCell("A1").alignment = { horizontal: "center" };
  wsAbn.getRow(2).values = ["Region", "Site", "Power Topology", "Site Down H", "Abnormal Days", "Total RH"];
  wsAbn.getRow(2).font = { bold: true };
  wsAbn.getRow(2).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFD9E1F2" } };
  abnormalDown.forEach((c, i) => {
    const r = i + 3;
    wsAbn.getCell(`A${r}`).value = c.region;
    wsAbn.getCell(`B${r}`).value = c.site;
    wsAbn.getCell(`C${r}`).value = c.powerTopology;
    wsAbn.getCell(`D${r}`).value = c.siteDownH;
    wsAbn.getCell(`E${r}`).value = c.abnormalDays;
    wsAbn.getCell(`F${r}`).value = c.totalRH;
  });
  wsAbn.columns = [{ width: 16 }, { width: 18 }, { width: 28 }, { width: 14 }, { width: 14 }, { width: 14 }];
  wsAbn.autoFilter = { from: "A2", to: "F2" };
  wsAbn.views = [{ state: "frozen", ySplit: 2 }];

  // ---- Summary ----
  const wsSum = wb.addWorksheet("Summary");
  wsSum.mergeCells("A1:B1");
  wsSum.getCell("A1").value = "Running Hours Analysis Summary";
  wsSum.getCell("A1").font = { bold: true, size: 14, color: { argb: "FFFFFFFF" } };
  wsSum.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F4E78" } };
  wsSum.getCell("A1").alignment = { horizontal: "center" };
  const meta: [string, number | string][] = [
    ["Period (days)", options.periodDays],
    ["Low Threshold (h)", options.lowThresholdHours],
    ["High Threshold (h)", options.highThresholdHours],
    ["Battery Abnormal Threshold (V)", options.batteryAbnormalThreshold],
    ["", ""],
    ["Total SLA sites in ERS", agg.size],
    ["Excluded — Not Communicating", excludedNoComm],
    ["Excluded — Open Power ticket", excludedOpenPower],
    ["Excluded — Open Generator ticket", excludedOpenGen],
    ["Candidates after exclusions", candidates.length],
    ["LOW RH (investigate)", lowSites.length],
    ["HIGH RH (investigate)", highSites.length],
    ["Abnormal Site Down", abnormalDown.length],
  ];
  meta.forEach((m, i) => {
    const r = i + 3;
    wsSum.getCell(`A${r}`).value = m[0];
    wsSum.getCell(`B${r}`).value = m[1];
    if (i < 4) wsSum.getCell(`A${r}`).font = { bold: true };
  });
  wsSum.getColumn(1).width = 38;
  wsSum.getColumn(2).width = 18;

  // Region distribution
  wsSum.getCell("D3").value = "Region";
  wsSum.getCell("E3").value = "Candidates";
  wsSum.getCell("F3").value = "LOW";
  wsSum.getCell("G3").value = "HIGH";
  ["D3", "E3", "F3", "G3"].forEach((c) => { wsSum.getCell(c).font = { bold: true }; });
  const regions = Array.from(new Set(list.map((l) => l.region))).filter(Boolean).sort();
  regions.forEach((reg, i) => {
    const r = i + 4;
    wsSum.getCell(`D${r}`).value = reg;
    wsSum.getCell(`E${r}`).value = candidates.filter((c) => c.region === reg).length;
    wsSum.getCell(`F${r}`).value = lowSites.filter((c) => c.region === reg).length;
    wsSum.getCell(`G${r}`).value = highSites.filter((c) => c.region === reg).length;
  });
  wsSum.getColumn(4).width = 18;
  [5, 6, 7].forEach((c) => { wsSum.getColumn(c).width = 12; });

  wsSum.addConditionalFormatting({
    ref: `E4:E${regions.length + 3}`,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rules: [{ type: "dataBar", priority: 1, cfvo: [{ type: "min" }, { type: "max" }], color: { argb: "FF1F4E78" } } as any],
  });
  wsSum.addConditionalFormatting({
    ref: `F4:F${regions.length + 3}`,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rules: [{ type: "dataBar", priority: 2, cfvo: [{ type: "min" }, { type: "max" }], color: { argb: "FFC00000" } } as any],
  });
  wsSum.addConditionalFormatting({
    ref: `G4:G${regions.length + 3}`,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rules: [{ type: "dataBar", priority: 3, cfvo: [{ type: "min" }, { type: "max" }], color: { argb: "FFED7D31" } } as any],
  });

  // ---- README ----
  const wsR = wb.addWorksheet("README");
  wsR.getColumn(1).width = 130;
  wsR.getCell("A1").value = "Running Hours Analysis — Logic";
  wsR.getCell("A1").font = { bold: true, size: 14 };
  const lines = [
    "",
    `Period analyzed: ${options.periodDays} days`,
    `Low threshold: ${options.lowThresholdHours}h total over the period — sites below are likely under-running and need investigation`,
    `High threshold: ${options.highThresholdHours}h total over the period — sites above ran too much, also investigate`,
    "",
    "Filters applied (in order):",
    "  1. SLA sites only (Project Status starts with 'SLA').",
    "  2. Exclude sites currently not communicating (Comm Report Status ≠ OK).",
    "  3. Exclude sites with an open Power ticket.",
    "  4. Exclude sites with an open Generator ticket.",
    "",
    "Candidates are then classified by Total RH using the formula in column G of 'All Sites RH'.",
    "",
    "Abnormal Site Down: sites flagged with SiteDown > 0h AND an abnormal load profile during the period.",
    "These are sites alarming as down but battery is healthy — close the alarm.",
    "",
    "All averages and flags are computed by Excel formulas — you can edit thresholds in O2/O3 of 'All Sites RH' and",
    "the Flag column will recalculate automatically.",
  ];
  lines.forEach((l, i) => { wsR.getCell(`A${i + 2}`).value = l; });

  const buffer = Buffer.from(await wb.xlsx.writeBuffer());
  const filename = `RunningHours_Analysis_${options.periodDays}d.xlsx`;

  return {
    buffer,
    filename,
    summary: {
      totalRows: ersRows.length,
      slaSites: agg.size,
      excludedNoComm,
      excludedOpenPower,
      excludedOpenGen,
      candidates: candidates.length,
      lowRH: lowSites.length,
      highRH: highSites.length,
      abnormalSiteDown: abnormalDown.length,
    },
  };
}
