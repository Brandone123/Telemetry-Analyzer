import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import { randomUUID } from "node:crypto";
import { analyzeNoCom } from "../analyses/no-com";
import { analyzeRunningHours } from "../analyses/running-hours";
import { analyzeFuelSensor } from "../analyses/fuel-sensor";
import { saveTemplate, loadTemplate, getTemplateInfo, deleteTemplate } from "../lib/template-storage";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024 } });
const router: IRouter = Router();

function getFile(req: Request, name: string): Buffer | null {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  if (!files) return null;
  const f = files[name]?.[0];
  return f ? f.buffer : null;
}
function getFileWithName(req: Request, name: string): { buffer: Buffer; originalname: string } | null {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  if (!files) return null;
  const f = files[name]?.[0];
  return f ? { buffer: f.buffer, originalname: f.originalname } : null;
}

// Temporary store for secondary downloads (ticket list, etc.)
// Auto-cleaned after 30 minutes so memory doesn't grow unbounded
const tempDownloads = new Map<string, { buffer: Buffer; filename: string; ts: number }>();
setInterval(() => {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [k, v] of tempDownloads) {
    if (v.ts < cutoff) tempDownloads.delete(k);
  }
}, 5 * 60 * 1000).unref();

// ----- SLA Tracker template management -----
router.get("/template/sla-tracker", async (_req, res) => {
  res.json(await getTemplateInfo("slaTracker"));
});

router.post(
  "/template/sla-tracker",
  upload.single("file"),
  async (req: Request, res: Response) => {
    const file = req.file;
    if (!file) { res.status(400).json({ error: "Missing 'file' field" }); return; }
    const info = await saveTemplate("slaTracker", file.buffer, file.originalname);
    res.json(info);
  },
);

router.delete("/template/sla-tracker", async (_req, res) => {
  await deleteTemplate("slaTracker");
  res.json({ ok: true });
});

// ----- Temporary file download -----
router.get("/analyses/download/:id", (req: Request, res: Response) => {
  const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const entry = id ? tempDownloads.get(id) : undefined;
  if (!entry) { res.status(404).json({ error: "Download not found or has expired" }); return; }
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${entry.filename}"`);
  res.send(entry.buffer);
});

// ----- NO COM analysis -----
router.post(
  "/analyses/no-com",
  upload.fields([
    { name: "slaTracker", maxCount: 1 },
    { name: "commReport", maxCount: 1 },
    { name: "noComTickets", maxCount: 1 },
  ]),
  async (req: Request, res: Response) => {
    try {
      let tracker = getFileWithName(req, "slaTracker");
      const comm = getFile(req, "commReport");
      const tickets = getFile(req, "noComTickets");
      if (!comm || !tickets) {
        res.status(400).json({ error: "commReport and noComTickets files are required" });
        return;
      }
      if (tracker) {
        await saveTemplate("slaTracker", tracker.buffer, tracker.originalname);
      } else {
        const stored = await loadTemplate("slaTracker");
        if (!stored) {
          res.status(400).json({ error: "No SLA Tracker template stored. Upload one first." });
          return;
        }
        tracker = { buffer: stored, originalname: "sla_tracker_template.xlsx" };
      }
      const cutoffDays = Number(req.body.cutoffDays ?? 2);
      const referenceDate = req.body.referenceDate ? new Date(String(req.body.referenceDate)) : new Date();
      const result = await analyzeNoCom(tracker.buffer, comm, tickets, { cutoffDays, referenceDate });
      // Persist the freshly updated tracker so the next analysis builds on top of today's data
      await saveTemplate("slaTracker", result.buffer, result.filename);
      // Store ticket list for secondary download
      const ticketListId = randomUUID();
      tempDownloads.set(ticketListId, {
        buffer: result.ticketListBuffer,
        filename: result.ticketListFilename,
        ts: Date.now(),
      });
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename="${result.filename}"`);
      res.setHeader("X-Analysis-Summary", encodeURIComponent(JSON.stringify(result.summary)));
      res.setHeader("X-Ticket-List-ID", ticketListId);
      res.setHeader("X-Ticket-List-Filename", result.ticketListFilename);
      res.send(result.buffer);
    } catch (err) {
      req.log.error({ err }, "no-com analysis failed");
      res.status(500).json({ error: (err as Error).message });
    }
  },
);

// ----- Running Hours analysis -----
router.post(
  "/analyses/running-hours",
  upload.fields([
    { name: "ersBigData", maxCount: 1 },
    { name: "commReport", maxCount: 1 },
    { name: "powerTickets", maxCount: 1 },
    { name: "genTickets", maxCount: 1 },
  ]),
  async (req: Request, res: Response) => {
    try {
      const ers = getFile(req, "ersBigData");
      if (!ers) {
        res.status(400).json({ error: "ersBigData file is required" });
        return;
      }
      const periodDays = Number(req.body.periodDays ?? 4);
      const lowThresholdHours = Number(req.body.lowThresholdHours ?? 80);
      const highThresholdHours = Number(req.body.highThresholdHours ?? periodDays * 22);
      const batteryAbnormalThreshold = Number(req.body.batteryAbnormalThreshold ?? 47.5);
      const result = await analyzeRunningHours(
        ers,
        getFile(req, "commReport"),
        getFile(req, "powerTickets"),
        getFile(req, "genTickets"),
        { periodDays, lowThresholdHours, highThresholdHours, batteryAbnormalThreshold },
      );
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename="${result.filename}"`);
      res.setHeader("X-Analysis-Summary", encodeURIComponent(JSON.stringify(result.summary)));
      res.send(result.buffer);
    } catch (err) {
      req.log.error({ err }, "running-hours analysis failed");
      res.status(500).json({ error: (err as Error).message });
    }
  },
);

// ----- Fuel Sensor analysis -----
router.post(
  "/analyses/fuel-sensor",
  upload.fields([
    { name: "componentsFile", maxCount: 1 },
    { name: "ticketsFile", maxCount: 1 },
  ]),
  async (req: Request, res: Response) => {
    try {
      const components = getFile(req, "componentsFile");
      const tickets = getFile(req, "ticketsFile");
      if (!components || !tickets) {
        res.status(400).json({ error: "componentsFile and ticketsFile are both required" });
        return;
      }
      const result = await analyzeFuelSensor(components, tickets);
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename="${result.filename}"`);
      res.setHeader("X-Analysis-Summary", encodeURIComponent(JSON.stringify(result.summary)));
      res.send(result.buffer);
    } catch (err) {
      req.log.error({ err }, "fuel-sensor analysis failed");
      res.status(500).json({ error: (err as Error).message });
    }
  },
);

export default router;
