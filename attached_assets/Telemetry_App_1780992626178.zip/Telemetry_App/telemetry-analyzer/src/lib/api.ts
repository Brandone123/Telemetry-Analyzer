const API_BASE = "/api";

export interface AnalysisSummary {
  [key: string]: unknown;
}

export interface AnalysisResponse {
  blob: Blob;
  filename: string;
  summary: AnalysisSummary | null;
}

export interface NoComAnalysisResponse extends AnalysisResponse {
  ticketListId?: string;
  ticketListFilename?: string;
}

async function postAnalysis(path: string, fd: FormData): Promise<AnalysisResponse> {
  const res = await fetch(`${API_BASE}${path}`, { method: "POST", body: fd });
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const j = await res.json();
      if (j?.error) msg = j.error;
    } catch {}
    throw new Error(msg);
  }
  const cd = res.headers.get("Content-Disposition") ?? "";
  const m = cd.match(/filename="?([^";]+)"?/);
  const filename = m ? m[1]! : "analysis.xlsx";
  const summaryRaw = res.headers.get("X-Analysis-Summary");
  let summary: AnalysisSummary | null = null;
  if (summaryRaw) {
    try { summary = JSON.parse(decodeURIComponent(summaryRaw)); } catch {}
  }
  const blob = await res.blob();
  return { blob, filename, summary };
}

export async function runNoComAnalysis(args: {
  slaTracker?: File | null;
  commReport: File;
  noComTickets: File;
  cutoffDays: number;
  referenceDate: string;
}): Promise<NoComAnalysisResponse> {
  const fd = new FormData();
  if (args.slaTracker) fd.append("slaTracker", args.slaTracker);
  fd.append("commReport", args.commReport);
  fd.append("noComTickets", args.noComTickets);
  fd.append("cutoffDays", String(args.cutoffDays));
  fd.append("referenceDate", args.referenceDate);

  const res = await fetch(`${API_BASE}/analyses/no-com`, { method: "POST", body: fd });
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const j = await res.json();
      if (j?.error) msg = j.error;
    } catch {}
    throw new Error(msg);
  }
  const cd = res.headers.get("Content-Disposition") ?? "";
  const m = cd.match(/filename="?([^";]+)"?/);
  const filename = m ? m[1]! : "analysis.xlsx";
  const summaryRaw = res.headers.get("X-Analysis-Summary");
  let summary: AnalysisSummary | null = null;
  if (summaryRaw) {
    try { summary = JSON.parse(decodeURIComponent(summaryRaw)); } catch {}
  }
  const ticketListId       = res.headers.get("X-Ticket-List-ID")       ?? undefined;
  const ticketListFilename = res.headers.get("X-Ticket-List-Filename") ?? undefined;
  const blob = await res.blob();
  return { blob, filename, summary, ticketListId, ticketListFilename };
}

export interface TemplateInfo {
  exists: boolean;
  filename?: string;
  sizeBytes?: number;
  uploadedAt?: string;
}

export async function getTemplateInfo(): Promise<TemplateInfo> {
  const res = await fetch(`${API_BASE}/template/sla-tracker`);
  return res.json();
}

export async function uploadTemplate(file: File): Promise<TemplateInfo> {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${API_BASE}/template/sla-tracker`, { method: "POST", body: fd });
  if (!res.ok) throw new Error(`Upload failed (${res.status})`);
  return res.json();
}

export async function deleteTemplate(): Promise<void> {
  await fetch(`${API_BASE}/template/sla-tracker`, { method: "DELETE" });
}

export async function runRunningHoursAnalysis(args: {
  ersBigData: File;
  commReport?: File | null;
  powerTickets?: File | null;
  genTickets?: File | null;
  periodDays: number;
  lowThresholdHours: number;
  highThresholdHours: number;
  batteryAbnormalThreshold: number;
}): Promise<AnalysisResponse> {
  const fd = new FormData();
  fd.append("ersBigData", args.ersBigData);
  if (args.commReport) fd.append("commReport", args.commReport);
  if (args.powerTickets) fd.append("powerTickets", args.powerTickets);
  if (args.genTickets) fd.append("genTickets", args.genTickets);
  fd.append("periodDays", String(args.periodDays));
  fd.append("lowThresholdHours", String(args.lowThresholdHours));
  fd.append("highThresholdHours", String(args.highThresholdHours));
  fd.append("batteryAbnormalThreshold", String(args.batteryAbnormalThreshold));
  return postAnalysis("/analyses/running-hours", fd);
}

export async function runFuelSensorAnalysis(args: {
  componentsFile: File;
  ticketsFile: File;
}): Promise<AnalysisResponse> {
  const fd = new FormData();
  fd.append("componentsFile", args.componentsFile);
  fd.append("ticketsFile", args.ticketsFile);
  return postAnalysis("/analyses/fuel-sensor", fd);
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 200);
}

export async function downloadTicketList(id: string, filename: string): Promise<void> {
  const res = await fetch(`${API_BASE}/analyses/download/${id}`);
  if (!res.ok) throw new Error(`Download failed (${res.status})`);
  const blob = await res.blob();
  downloadBlob(blob, filename);
}
